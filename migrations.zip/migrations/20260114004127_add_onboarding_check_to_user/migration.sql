-- AlterTable
ALTER TABLE "users" ADD COLUMN     "isOnboardingCompleted" BOOLEAN NOT NULL DEFAULT false;
